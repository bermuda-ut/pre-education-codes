//
//  Constants.h
//  AdColonyV4VC
//
//  Created by John Fernandes-Salling on 8/16/12.
//

#define kCurrencyBalance @"CurrencyBalance"
#define kCurrencyBalanceChange @"CurrencyBalanceChange"

#define kZoneLoading @"ZoneLoading"
#define kZoneReady @"ZoneReady"
#define kZoneOff @"ZoneOff"
