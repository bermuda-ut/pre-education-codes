//
//  ViewController.h
//  AdColonyAdvanced
//
//  Created by John Fernandes-Salling on 9/12/12.
//

#import <UIKit/UIKit.h>
#import <AdColony/AdColony.h>

@interface ViewController : UIViewController <AdColonyAdDelegate>
@end
