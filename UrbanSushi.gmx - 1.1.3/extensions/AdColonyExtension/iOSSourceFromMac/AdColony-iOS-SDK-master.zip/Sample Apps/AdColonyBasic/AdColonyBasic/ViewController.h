//
//  ViewController.h
//  AdColonyBasic
//
//  Created by John Fernandes-Salling on 8/14/12.
//

#import <UIKit/UIKit.h>


@interface ViewController : UIViewController

@end
