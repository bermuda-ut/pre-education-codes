//
//  ViewController.h
//  AdColonyV4VC
//
//  Created by John Fernandes-Salling on 8/15/12.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
